
DELIMITER $$
CREATE PROCEDURE `names23`(IN `var` VARCHAR(20))
BEGIN
	select CUST_NAME
	from customer
	where WORKING_AREA = var;
END$$
DELIMITER ;


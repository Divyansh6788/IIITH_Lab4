
DELIMITER $$
CREATE PROCEDURE `total2`(OUT `sum` INT,IN `var1` INT,IN `var2` INT)
BEGIN
	Set sum = var1 + var2;
END$$
DELIMITER ;
